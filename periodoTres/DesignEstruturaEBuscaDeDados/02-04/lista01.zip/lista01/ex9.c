#include <stdio.h>
void main(){
    int valor = 2567;
    
    printf("valor em Decimal : %d\n",valor);
    printf("valor em Octal : %o\n",valor);
    printf("valor em Hexadecimal (letras em minusculas): %x\n",valor);
    printf("Hexadecimal value is (letras em maiusculas): %X\n",valor);
}