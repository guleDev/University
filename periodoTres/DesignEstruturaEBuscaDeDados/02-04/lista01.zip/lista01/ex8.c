#include <stdio.h>

void main() {
    int idade = 20;
    printf("%d\n", idade);
    printf("%p\n", &idade);
}